# Tarea 1.2 - Clasificación y arquitecturas (ANSI/SPARC y SGBD)

**Institución:** Instituto Tecnológico Superior de Monclova  
**Alumno:** Aldo Alberto Barajas Ancira  
**Docente:** Rubén Riojas  
**Asignatura:** Bases de Datos  
**Unidad:** 1. Introducción a las bases de datos  
**Fecha:** 2 de noviembre de 2026

## Competencia y objetivo

Comprender los distintos criterios para clasificar bases de datos e interpretar la arquitectura de tres esquemas ANSI/SPARC y los módulos internos de un SGBD, explicando cómo fluye la información desde el usuario hasta el almacenamiento.

## 1. Clasificación de las bases de datos

Una base de datos almacena información organizada y un SGBD administra su estructura, consulta, actualización, integridad y seguridad (OpenStax, 2024). **No existe una sola clasificación excluyente:** diferentes criterios pueden aplicarse a la misma base.

![Cuadro sinóptico](Diagramas/Cuadro_Sinoptico_Clasificacion.svg)

| Criterio | Categorías | Definición y ejemplo |
|---|---|---|
| Ubicación del alojamiento | Local, nube, híbrida | Determina dónde residen el sistema y los datos. Una universidad puede ejecutar su motor localmente o contratar infraestructura de nube. |
| Distribución | Centralizada, distribuida, federada | En un sitio lógico o varios nodos/fuentes coordinados; no equivale por sí mismo a estar en la nube. |
| Variabilidad del contenido | Estática, dinámica | Datos con pocas modificaciones (archivo histórico) frente a altas, bajas y cambios constantes (inventario). |
| Finalidad | OLTP, OLAP | Operaciones transaccionales diarias frente a análisis histórico de grandes conjuntos. |
| Representación | Estructurada, semiestructurada, no estructurada | Tablas SQL, documentos JSON/XML o multimedia. |
| Modelo | Relacional, documentos, clave-valor, grafo, etc. | El modelo define cómo se representan los elementos y sus relaciones. |
| Acceso | Monousuario, multiusuario | Un usuario por vez frente a concurrencia de múltiples usuarios. |

Una base de datos de inscripciones es, al mismo tiempo, relacional, dinámica, operacional, multiusuario y potencialmente alojada en la nube. La clasificación «estática/dinámica» describe **variabilidad del contenido**, no asignación de memoria en un programa.

## 2. Arquitectura ANSI/SPARC: tres esquemas

ANSI/SPARC distingue los niveles **externo, conceptual e interno**. Su propósito es separar las aplicaciones del almacenamiento y facilitar la independencia de datos (Teradata, s. f.; Edinburgh Napier University, s. f.).

![Diagrama ANSI/SPARC](Diagramas/Arquitectura_ANSI_SPARC.svg)

**Nivel externo (vistas):** ofrece perspectivas distintas según el usuario. Un alumno ve su historial, el docente ve un grupo y control escolar puede acceder a datos administrativos. Cada vista expone información pertinente y autorizada.

**Nivel conceptual (lógico global):** representa entidades, atributos, relaciones y restricciones de la base en su conjunto. Para una escuela, podría describir `Alumnos`, `Materias`, `Inscripciones` y reglas sobre ellas.

**Nivel interno (físico):** describe archivos, páginas, índices y accesos físicos administrados por el SGBD. No debe confundirse con el nivel físico del hardware: trata de **cómo se representan y acceden los datos en el almacenamiento**.

### Ejemplo de flujo de una consulta

1. El alumno solicita su calificación desde una aplicación (vista externa).
2. Se resuelve la correspondencia entre la vista externa y el esquema conceptual, respetando permisos.
3. El motor accede a estructuras físicas, como páginas e índices, para recuperar registros.
4. El resultado regresa a través de las correspondencias hasta la vista autorizada.

**Independencia física:** permite cambiar índices u organización de archivos sin necesidad de alterar la estructura lógica de la base ni las vistas. **Independencia lógica:** permite absorber ciertas modificaciones conceptuales sin modificar vistas externas, aunque resulta más compleja y no es absoluta.

## 3. Arquitectura funcional interna del SGBD

A diferencia de ANSI/SPARC, que define niveles de **abstracción de los datos**, la arquitectura funcional identifica componentes del software que atienden consultas, administran el almacenamiento y preservan consistencia y disponibilidad. Un motor relacional típico puede incluir los siguientes módulos (OpenStax, 2024; PostgreSQL Global Development Group, s. f.):

![Diagrama SGBD](Diagramas/Arquitectura_Funcional_SGBD.svg)

| Módulo | Función |
|---|---|
| Gestión de sesiones y seguridad | Autentica usuarios, recibe solicitudes, aplica privilegios. |
| Analizador y validador de consultas | Comprueba sintaxis, nombres, permisos y semántica. |
| Optimizador | Evalúa planes alternativos y selecciona uno para la consulta. |
| Ejecutor | Ejecuta el plan y entrega resultados. |
| Gestor de almacenamiento | Organiza páginas, archivos e índices y coordina búferes. |
| Gestor de transacciones | Administra atomicidad, aislamiento y concurrencia. |
| Registro y recuperación | Conserva registros y mecanismos que apoyan durabilidad y recuperación ante fallos. |
| Catálogo / diccionario de datos | Guarda información sobre tablas, columnas, restricciones y privilegios. |

### Ruta de procesamiento

Consulta SQL → autenticación → análisis → optimización → ejecución → lectura/escritura mediante gestor de almacenamiento → resultados. Los gestores de transacciones y recuperación respaldan las operaciones según las necesidades del motor. Estos pasos no siempre son procesos independientes; el diseño varía entre motores.

Ejemplo: `SELECT nombre FROM Alumnos WHERE matricula = 2501;` puede llevar al optimizador a usar un índice si existe y resulta conveniente. El ejecutor solicita los datos al gestor de almacenamiento, que puede recuperarlos del búfer o leer páginas almacenadas.

## 4. Comparación: ANSI/SPARC vs. SGBD interno

| Pregunta | ANSI/SPARC | Arquitectura funcional SGBD |
|---|---|---|
| ¿Qué describe? | Vistas y niveles de descripción de los datos. | Componentes y flujo de trabajo del motor. |
| ¿Cuál es su propósito? | Abstracción e independencia de datos. | Consultas, almacenamiento, seguridad, transacciones y recuperación. |
| ¿Cuáles son sus elementos? | Externo, conceptual e interno. | Analizador, optimizador, ejecutor, almacenamiento, control transaccional, etc. |
| ¿Cómo se relacionan? | El gestor transforma las solicitudes entre niveles de abstracción. | Sus módulos implementan esas operaciones y administran la persistencia. |

## 5. Conclusión

La clasificación multidimensional permite seleccionar tecnologías conforme al contexto. ANSI/SPARC separa las vistas de los usuarios, el modelo conceptual y el almacenamiento, favoreciendo mantenimiento e independencia de datos. La arquitectura funcional muestra cómo un SGBD hace posible consultar, transformar, almacenar y recuperar información. Las dos perspectivas son complementarias: una explica **cómo se organiza la representación de los datos** y la otra **cómo opera el software gestor**.

## 6. Referencias (APA 7)

- Edinburgh Napier University. (s. f.). *3-level architecture*. https://bdavison.napier.ac.uk/db/Notes/Introduction/architecture/
- IBM. (s. f.). *¿Qué es la arquitectura de datos?* https://www.ibm.com/mx-es/think/topics/data-architecture
- IBM. (s. f.). *¿Qué es una base de datos?* https://www.ibm.com/mx-es/think/topics/database
- OpenStax. (2024). *8.2 Data management systems*. En *Introduction to computer science*. Rice University. https://openstax.org/books/introduction-computer-science/pages/8-2-data-management-systems
- PostgreSQL Global Development Group. (s. f.). *Overview of PostgreSQL internals*. https://www.postgresql.org/docs/current/overview.html
- Teradata. (s. f.). *ANSI/X3/SPARC three schema architecture*. https://docs.teradata.com/r/Enterprise_IntelliFlex_VMware/Database-Design/Database-Design-for-Vantage/ANSI/X3/SPARC-Three-Schema-Architecture

## 7. Enlaces de entrega

- **Repositorio GitHub público:** [pegar URL de carpeta publicada]
- **Video público de YouTube:** [pegar URL del video publicado en el mismo canal]
