# Guion para YouTube - Tarea 1.2 de Bases de Datos

**Duración estimada:** entre 4 y 5 minutos.  
**Escenario:** grabación de pantalla mostrando el PDF, con cámara web en esquina inferior derecha.

## 0:00-0:20 | Presentación

«Hola. Soy Aldo Alberto Barajas Ancira, del Instituto Tecnológico Superior de Monclova. En esta tarea explicaré cómo se clasifican las bases de datos, la arquitectura ANSI/SPARC de tres niveles y los componentes internos de un sistema gestor de bases de datos».

## 0:20-1:20 | Cuadro sinóptico

«Las bases de datos se pueden clasificar por distintos criterios. Por ubicación pueden ser locales, en la nube o híbridas. Por distribución pueden ser centralizadas, distribuidas o federadas. Según la variabilidad del contenido hay estáticas y dinámicas. Según el propósito se distinguen las operacionales u OLTP y las analíticas u OLAP. También pueden ser relacionales o no relacionales, de uso individual o multiusuario. Estos criterios se combinan: un sistema de calificaciones puede ser relacional, dinámico, multiusuario y estar alojado en la nube».

## 1:20-2:35 | Arquitectura ANSI/SPARC

«ANSI/SPARC plantea tres niveles. El externo es lo que cada usuario puede ver. Por ejemplo, un alumno ve sus calificaciones, pero no necesariamente la información de otros. El conceptual describe la estructura completa, con alumnos, materias e inscripciones. El interno define cómo se almacenan los datos mediante páginas, archivos e índices. Cuando hacemos una consulta, el sistema interpreta la vista externa, la relaciona con el esquema conceptual, accede a las estructuras físicas y devuelve el resultado. Esta separación ayuda a mantener la independencia de los datos».

## 2:35-3:55 | Arquitectura funcional del SGBD

«La arquitectura funcional muestra módulos del software, no niveles de abstracción. Al recibir SQL, el sistema valida la sesión y los permisos. El analizador verifica la consulta; el optimizador decide cómo resolverla; el ejecutor realiza las operaciones. Para buscar registros, solicita acceso al gestor de almacenamiento y sus búferes. Los gestores de transacciones y recuperación ayudan a coordinar cambios simultáneos y a proteger datos frente a fallos».

## 3:55-4:30 | Conclusión

«En conclusión, clasificar bases de datos sirve para elegir tecnologías según las necesidades de una organización. ANSI/SPARC explica cómo se separan las distintas vistas de los datos. Por otro lado, la arquitectura funcional describe cómo el gestor procesa realmente las consultas. Ambas son necesarias para entender el funcionamiento de un sistema de bases de datos».

## Grabación con OBS

1. Abre OBS Studio y crea una escena «Tarea 1.2 BD».
2. Agrega **Captura de pantalla** y selecciona el monitor donde se ve el PDF.
3. Agrega **Dispositivo de captura de video** para tu webcam.
4. Coloca la cámara en la **esquina inferior derecha**, sin tapar diagramas o texto esencial.
5. Verifica audio de micrófono y haz una grabación de prueba breve.
6. Graba mostrando el cuadro sinóptico y los dos diagramas. Sube el video como **Público** en el mismo canal donde publicas las demás tareas.
7. Copia su URL pública y entrégala junto con el enlace de la carpeta de GitHub en Teams.
