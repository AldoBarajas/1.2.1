# Tarea 1.2 · Clasificación y arquitecturas de bases de datos

**Alumno:** Aldo Alberto Barajas Ancira  
**Docente:** Rubén Riojas  
**Institución:** Instituto Tecnológico Superior de Monclova

## Archivos

- `Tarea_1_2_Bases_de_Datos_ANSI_SPARC_Aldo_Barajas.pdf`: documento académico (9 páginas).
- `Investigacion_Tarea_1_2.md`: contenido editable con explicaciones, cuadro comparativo y bibliografía.
- `Diagramas/Cuadro_Sinoptico_Clasificacion.svg`: fuente vectorial del cuadro sinóptico.
- `Diagramas/Arquitectura_ANSI_SPARC.svg`: esquema editable de los tres niveles.
- `Diagramas/Arquitectura_Funcional_SGBD.svg`: esquema editable del procesamiento interno de consultas.
- `Guion_YouTube.md`: guion de exposición y configuración de OBS.

## Cómo subir a GitHub

1. Descomprime la entrega. Entra a tu repositorio público de Bases de Datos.
2. En la pestaña **Código**, elige **Agregar archivo → Cargar archivos**.
3. Arrastra la carpeta `Bases_de_Datos` descomprimida. Comprueba que se respete la ruta `Bases_de_Datos/Unidad_1/Tarea_1_2/`.
4. Elige **Confirmar cambios**. Copia la URL de esa carpeta.
5. Añade el enlace público de YouTube a Teams junto con la URL del repositorio.

> Los dos enlaces públicos son acciones que deben realizarse desde tu propia cuenta; no hay URL que pueda proporcionarse hasta publicar los contenidos.
